<html>
<body>
<?php
include('include/config.php');
if(isset($_GET['id']))
{
$id=$_GET['id'];
$query1=mysql_query("delete from report_backup where id='$id'");
if($query1)
{
header('location:manage_report.php');
}
}
?>
</body>
</html>