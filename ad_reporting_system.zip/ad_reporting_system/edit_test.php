<?php
include('include/config.php');
include("include/header.php");
if(isset($_GET['id']))
{
$id=$_GET['id'];
if(isset($_POST['submit']))
{
$query=mysql_query("update report_backup set date_time='".$_POST['date_time']."', impration='".$_POST['impration']."', click='".$_POST['click']."',campaign_name='".$_POST['selectCampaign']."' where id='$id'");
if($query)
{
header('location:manage_report.php');
}
}
//echo "select * from report_backup where id='".$id."'";
$query1=mysql_query("select * from report_backup where id='".$_GET['id']."'");
$rs=mysql_fetch_array($query1);

}
?>

<div id="main-content"> <!-- Main Content Section with everything --> 
  <!---------- standard script---------------------> 
  
  <!---------- standard script--------------------->
  <div class="content-box">
    <div class="content-box-header">
      <h3>Add/Edit Report</h3>
      <ul class="content-box-tabs">
        <li><a href="#tab1" class="default-tab"></a></li>
      </ul>
      <div class="clear"></div>
    </div>
    <div class="content-box"><!-- Start Content Box -->
      
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
          
          <form action="" method="post" name="form1">
            <fieldset>
            <p>
                <label>Date</label>
                <input type="text" value="<?php echo $rs['date_time'];?>" name="date_time" id="Datepicker1"/>
                <br />
              </p>

                           
                <label>Impression</label>
                <input type="text" id="medium-input" value="<?php echo $rs['impration'];?>" name="impration"/>
                <br />
              </p>
              <p>
                <label>Click</label>
                <input type="text" id="medium-input" value="<?php echo $rs['click'];?>" name="click" />
                <br />
              </p>
              <p>
                <label>Campaign Name</label>
                <select name="selectCampaign">
              <option>-select-</option>
              <?php
			 // $selectCamp = mysql_query("select campaign_name from da_airport_reportBackup where publisher_name = '".$_SESSION['airportName']."' group by campaign_name",$con1) or die(mysql_error());
			  $selectCamp = mysql_query("SELECT `campaign_name` FROM  `report_backup` GROUP BY `campaign_name` ",$con1) or die(mysql_error());
			  while($campName = mysql_fetch_array($selectCamp))
			  {
			   ?>
              <option value="<?php echo $campName['campaign_name']; ?>"><?php echo $campName['campaign_name']; ?></option>
              
              
             <?php }?>
            

              </select>
                <input type="hidden" name="campaign_name" value="<?php echo $rs['campaign_name'];?>">
                
                <br />
              </p>
              </select>                
                <br />
              </p>              <p>
                <input class="button" type="submit" name="submit" value="Update" />
              </p>
            </fieldset>
            <div class="clear"></div>
            <!-- End .clear -->
            
          </form>
        </div>
        <!-- End #tab1 --> 
      </div>
      <!-- End .content-box-content --> 
      
    </div>
    <!-- End .content-box-content --> 
    
  </div>
  <script language="javascript">

function calRevanue() {
       var txtFirstNumberValue = document.getElementsByName("ad_view");
       var txtSecondNumberValue = document.getElementsByName("rate");
       if (txtFirstNumberValue[0].value == "")
           txtFirstNumberValue[0].value = 0;
       if (txtSecondNumberValue[0].value == "")
           txtSecondNumberValue[0].value = 0;

       var result = parseFloat(txtFirstNumberValue[0].value) * parseFloat(txtSecondNumberValue[0].value);

       result = parseFloat(result).toFixed(2);

       if (!isNaN(result)) {
           document.getElementsByName("revenue")[0].value = result;
       }
   }
   
   
   
</script> 
  <!-- End .content-box -->
  <?php include("include/footer.php"); ?>
