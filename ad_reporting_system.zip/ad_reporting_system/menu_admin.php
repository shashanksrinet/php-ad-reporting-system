<?php 
include("config.php");
ob_start();
?>
  <ul id="main-nav">
    <li><a href="add_report.php" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">add_report</font></a></li>
    <li><a href="manage_report.php" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Manage_report</font></a></li>                          
     <li><a href="reporting_system.php" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Client_report</font></a></li>                
  <ul>
</ul>
