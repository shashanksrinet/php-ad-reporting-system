/*
  jQuery Document ready
*/
$(function()
{
	$('#end_date').datetimepicker(
	{
		/*
			timeFormat
			Default: "HH:mm",
			A Localization Setting - String of format tokens to be replaced with the time.
		*/
		timeFormat: 'HH:mm:ss',
		/*
			hourMin
			Default: 0,
			The minimum hour allowed for all dates.
		*/
		stepHour: 1,
	stepMinute: 1,
	stepSecond: 1
	});


	$('#start_date').datetimepicker(
	{
		/*
			timeFormat
			Default: "HH:mm",
			A Localization Setting - String of format tokens to be replaced with the time.
		*/
		timeFormat: 'HH:mm:ss',
		/*
			hourMin
			Default: 0,
			The minimum hour allowed for all dates.
		*/
		stepHour: 1,
	stepMinute: 1,
	stepSecond: 1
	});
	
	/*
		below code just enable time picker.
	*/	
	//$('#basic_example_2').timepicker();
});
