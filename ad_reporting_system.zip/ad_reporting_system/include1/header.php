<?php
$_SESSION['start'] = time(); // taking now logged in time
    if(!isset($_SESSION['expire'])){
        $_SESSION['expire'] = $_SESSION['start'] + (1* 36 * 30) ; // ending a session in 30 seconds
    }
    $now = time(); // checking the time now when home page starts
    if($now > $_SESSION['expire'])
    {        session_destroy();
        header('location:index.php');
    }
	
	if($_SESSION['user_level'] != '0' && $_SESSION['user_level'] != '1' && $_SESSION['user_level'] != '6'){
	echo "This page not available!";
	header('location:index.php');}
	
    ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Spidio Reporting System</title>
<link rel="shortcut icon" href="resources/favicon.ico">
<!--                       CSS                       -->

<!-- Reset Stylesheet -->

<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />

<!-- Main Stylesheet -->

<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />

<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->

<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />


<!--                       Javascripts                       -->
<!-- date picker strat-->
<link href="date_picker/jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="date_picker/jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="date_picker/jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">

<!-- date picker end-->
<!-- jQuery -->

<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>

<!-- jQuery Configuration -->

<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>

<!-- Facebox jQuery Plugin -->

<script type="text/javascript" src="resources/scripts/facebox.js"></script>

<!-- jQuery WYSIWYG Plugin -->

<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>

<!-- jQuery DateTime Picker -->

<script type="text/javascript" src="js/jquery/jquery.datePicker.js"></script>



<!-- Internet Explorer .png-fix -->

</head>

<body>
<div id="body-wrapper">
<!-- Wrapper for the radial gradient background -->

<div id="sidebar">
  <div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
    
    <h1 id="sidebar-title"><a href="#"><?php echo $site_name; ?></a></h1>
    
    <!-- Logo (221px wide) --> 
    
    <a href="#"><img id="logo" src="resources/images/logo.png" alt="Admin logo" width="208px" height="96px" style="padding-left:7px;"/></a> 
    
    <!-- Sidebar Profile links -->
    
    <div id="profile-links"> 
      
      <!--	Hello, <a href="#" title="Edit your profile">John Doe</a>, you have <a href="#messages" rel="modal" title="3 Messages">3 Messages</a><br />

				<br />

				<a href="#" title="View the Site">View the Site</a> | -->
      <h3><a href="logout.php" title="Sign Out">Log Out</a></h3>
    </div>
    <?php  include("menu.php");?>
    <!-- End #main-nav --> 
    
  </div>
</div>
<!-- End #sidebar -->
