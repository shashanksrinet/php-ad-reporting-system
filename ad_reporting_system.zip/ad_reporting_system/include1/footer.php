			<div class="clear"></div>			
			<div id="footer">
				<small>
						&#169; Copyright 2014 <!--Simpla Admin | Powered by <a href="http://themeforest.net/item/simpla-admin-flexible-user-friendly-admin-skin/46073">Simpla Admin</a> | <a href="#">Top</a>-->
				</small>
			</div><!-- End #footer -->
			
		</div> <!-- End #main-content -->
		
	</div></body>
<script src="date_picker/jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="date_picker/jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});


$(function() {
	$( "#Datepicker2" ).datepicker(); 
});

</script>
  
</html>
