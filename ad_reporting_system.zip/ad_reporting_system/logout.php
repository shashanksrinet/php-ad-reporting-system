<?php
session_start();
session_destroy();
$_SESSION['admin_username'] == '';
unset($_SESSION['user_lavel']);
header("Location:index.php");
?>