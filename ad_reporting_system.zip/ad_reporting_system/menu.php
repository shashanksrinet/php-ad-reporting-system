<?php 

include("config.php");



ob_start();

?>

 
  <ul id="main-nav">
  <li><a href="#" class="nav-top-item" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Silicon India</font></a></li>
                
               
                
     
                <ul>
                <?php if($_SESSION['user_level'] =='0'){?>
                <li><a href="delhiAirport.php?airport=Delhi_Airport">Delhi Airport</a></li>
                <li><a href="mumbaiAirport.php?airport=Mumbai_Airport">Mumbai Airport</a></li>
                <li><a href="bangaloreAirport.php?airport=Bangalore_Airport">Bangalore Airport</a></li>
                <?php } ?>
                </ul>
  <ul>
  
  <?php if($_SESSION['user_level'] =='0'){?>
  <ul id="main-nav">
  <li><a href="#" class="nav-top-item" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Campaign's</font></a></li>
                <ul>
                <li><a href="addCampaign.php">Create Campaign</a></li>
                <li><a href="manageCampaign.php">Manage Campaign</a></li>
                <li></li>
                </ul>
  
  <?php } ?>

</ul>
