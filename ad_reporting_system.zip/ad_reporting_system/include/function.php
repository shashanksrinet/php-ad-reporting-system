<?php
$request_uri = $_SERVER['REQUEST_URI']; 
$page_name = basename($_SERVER['SCRIPT_NAME'],".php"); 
$pageName = str_replace('_',' ',$page_name);
$tab = ucwords($pageName);  
$title = $site_name." | ".$tab;
$id = $_GET['id'];
function sqlQuery($sql){

	$result = mysql_query($sql) or die("<span style='FONT-SIZE:11px; FONT-COLOR: #000000; font-family=tahoma;'><center>An Internal Error has Occured. Please report following error to the webmaster.<br><br>".$sql."<br><br>".mysql_error()."'</center></FONT>");

	return $result;

} 



function getSingleResult($sql){
	$response = "";
	$result = mysql_query($sql) or die("<center>An Internal Error has Occured. Please report following error to the webmaster.<br><br>".$sql."<br><br>".mysql_error()."'</center>");
	 $response = mysql_fetch_array($result);
	return $response;
} 



function fetchData($sql){
	$query = mysql_query($sql) or die("<center>An Internal Error has Occured. Please report following error to the webmaster.<br><br>".$sql."<br><br>".mysql_error()."'</center>");
	while($result = mysql_fetch_array($query)){
		$results[] = $result;
	} 
	return $results;
}



function num_rows($sql){
	$nums = "";
	$query = mysql_query($sql) or die("<center>An Internal Error has Occured. Please report following error to the webmaster.<br><br>".$sql."<br><br>".mysql_error()."'</center>");
	$nums = mysql_num_rows($query);
	return $nums;
} 

// random key generator
function parentRandomKey(){
		$sql = "select * from users where username LIKE 'RR0010%' order by id desc limit 1";
		$random_key_rows = num_rows($sql);
		if($random_key_rows == 0){
			$new_random_key = "RR00100101";
		}else{
			$fetch_old_random_key = getSingleResult($sql);
			$old_random_key_int = substr($fetch_old_random_key['username'],7);
			$random_key_successor = $old_random_key_int+1;
			$new_random_key = "RR00100".$random_key_successor;
		}
	return $new_random_key;
}

function childRandomKey($p_id){
		$sql = "select * from users where username LIKE 'RR0020%' order by id desc limit 1";
		$random_key_rows = num_rows($sql);
		if($random_key_rows == 0){
			$new_random_key = "RR00200201";
		}else{
			$fetch_old_random_key = getSingleResult($sql);
			$old_random_key_int = substr($fetch_old_random_key['username'],7);
			$random_key_successor = $old_random_key_int+1;
			$new_random_key = "RR00200".$random_key_successor;
		}
	return $new_random_key;
}
function money($user_id){
	//OLD VERSION
	/*
	$sql = "select SUM(amount) as total from transaction_log where user_id = '".$user_id."' and money_flag = '1'";
	$deposit = getSingleResult($sql);

	$sql = "select SUM(amount) as total from transaction_log where parent_id = '".$user_id."' and money_flag = '0'";
	$withdrawal = getSingleResult($sql);
	$total_money = $deposit['total']-$withdrawal['total'];
	return $total_money;*/
	
	//NEW VERSION
	$sql = "select SUM(amount) as total from transaction_log where user_id = '".$user_id."' and transaction_type_id in (6,1,3,4) and status=1";
	$deposit = getSingleResult($sql);
	
	$sql = "select SUM(amount) as total from transaction_log where user_id = '".$user_id."' and transaction_type_id in (5,7) and status=1";
	$game_lose = getSingleResult($sql);
	
	$sql = "select SUM(amount) as total from transaction_log where parent_id = '".$user_id."' and transaction_type_id in (1) ";
	$withdrawal = getSingleResult($sql);
	
	$total_money = $deposit['total'] -$game_lose['total']-$withdrawal['total'];
	return $total_money;
}



function notification(){
 if(!empty($_SESSION['notification'])){
	 if (strpos($_SESSION['notification'],'Error!') !== false) {
	echo "<div class='notification error png_bg'><div>";
	}else{
	echo "<div class='notification success png_bg'><div>";
	}
	echo $_SESSION['notification'];
	unset($_SESSION['notification']);
	echo "</div></div>";
 }
}

//get  transaction log

function transaction_log($tl_limit){
	$sql = "select * from transaction_log where user_id = '".$_SESSION['user_id']."'  order by id desc limit $tl_limit";
	$result = fetchData($sql);
	return $result;
}

function transaction($money_user_id,$t_t_i,$amount){

	$sql= "insert into transaction_log(user_id,amount,transaction_type_id,status,log_date,log_time) values('".$money_user_id."','".$amount."','".$t_t_i."','1','".date('Y-m-d')."','".date('H:i:s')."')";
	sqlQuery($sql);
}


function getUserName($id){
	$sql = "select * from users where id = '".$id."'";
	$p_result = getSingleResult($sql);
	return $p_result['username'];
}

function fetchPage($page_type){
	$sql = "select * from pages where page = '".$page_type."'";
	$page_result  = getSingleResult($sql);
	return $page_result['description'];
}

