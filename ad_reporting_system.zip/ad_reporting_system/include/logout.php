<?php
session_start();
session_destroy();
$_SESSION['admin_username'] == '';
unset($_SESSION['admin_username']);
header("Location:index.php");
?>