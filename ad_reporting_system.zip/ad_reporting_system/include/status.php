<?php
include("config.php");
if($_REQUEST['type']){
	if($_REQUEST['status'] == 0){
		$status = 1;
	}else{
		$status = 0;
	}
	mysql_query("update ".$_REQUEST['type']." set is_active = '".$status."' where id = '".$_REQUEST['id']."'") or die(mysql_error());
	header("location:http://localhost".$_REQUEST['request_uri']);
}
 ?>