			<div class="clear"></div>			
			<div id="footer">
				<small>
						&#169; Copyright <?php echo date('Y');?>
				</small>
			</div><!-- End #footer -->
			
		</div> <!-- End #main-content -->
		
	</div></body>
<script src="date_picker/jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="date_picker/jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});


$(function() {
	$( "#Datepicker2" ).datepicker(); 
});

</script>
  
</html>
