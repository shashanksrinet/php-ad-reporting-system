<?php 

include("config.php");



ob_start();

?>



<ul id="main-nav">







 

    

   

  

 <li> <a href=\"#\" class=\"nav-top-item\">Manage Report </a>

   <ul>

    <li><a href=\"date_report.php\">Add Date Report</a></li>

	
  </ul>

 </li>

 
  

  

  

</ul>

