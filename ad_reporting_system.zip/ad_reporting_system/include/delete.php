<?php
include("config.php");
if($_REQUEST['type']){
	mysql_query("delete from ".$_REQUEST['type']." where id = '".$_REQUEST['id']."'") or die(mysql_error());
	mysql_query("delete from ".$_REQUEST['type']." where parent_id = '".$_REQUEST['id']."'") or die(mysql_error());
	header("location:http://localhost".$_REQUEST['request_uri']);
}
 ?>