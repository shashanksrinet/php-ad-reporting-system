<?php
session_start();
ob_start();
error_reporting(0);
mysql_connect('localhost','root','K4hvdQ9tj9');
mysql_select_db('campaign');
?>