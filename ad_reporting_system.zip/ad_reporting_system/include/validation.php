<?php 
/*if($_SESSION['user_level'] == 2 )
{
	echo "Sorry, This page not exit."; exit;
}elseif($_SESSION['user_level'] == 1 )
{
	echo "Sorry, This page not exit."; exit;
}
*/
?>