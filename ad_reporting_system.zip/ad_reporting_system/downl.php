<?php

include("include/config.php");
/*------------------------*/
function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
  }

  // filename for download
  $filename =  "Download".date('Ymd').".xls";
  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel; charset=utf-8");

  $flag = false;
  //echo "select * from da_airport_report where campaign_name = '".$_POST['selectCampaign']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."'";exit;
  $SNo=1;
  $result = mysql_query("select * from report_backup where campaign_name = '".$_GET['campName']."' AND date_time BETWEEN '".$_GET['sDate']."' AND '".$_GET['eDate']."'") or die('Query failed!');
  while(false !== ($row = mysql_fetch_assoc($result))) {
	  
    if(!$flag) {
      // display field/column names as first row
	  //echo ucwords(implode("\t", array_keys($row))) . "\r\n";
	  echo "Date"."\t"."Imp"."\t"."Clicks"."\t"."CTR%"."\t";
	  
	  $flag = true;
    }
	 		
			
/*----------calculation ctr---------*/
			$var_click = $row['click'];
			$var_imp = $row['impration'];
			$dateCTR = ($var_click/$var_imp)*100;
			$ctrDate = number_format($dateCTR, 2, '.', '');
			$spend = $row['click']*$row['cpc'];
	 //array_walk($row, 'cleanData');
    echo "\r\n".$row['date_time']."\t".$row['impration']."\t".$row['click']."\t".$ctrDate;
  }
  
  					
					$reportQuery = mysql_query("select sum(impration) as tView,sum(click) as tClick  from report_backup where campaign_name = '".$_GET['campName']."' AND date_time BETWEEN '".$_GET['sDate']."' AND '".$_GET['eDate']."'") or die(mysql_error());
			$showTotal = mysql_fetch_array($reportQuery);
			$tx = $showTotal['tView'];
			$ty = $showTotal['tClick'];
			
			  
			   //$tCpc = mysql_fetch_array(mysql_query('SELECT SUM(`cpc`) as dCpc FROM `easypolicy` '));
			  $t_ctr = ($ty/$tx)*100;
			  $total_ctr = number_format($t_ctr, 2, '.', '');
					
					
  echo   "\r\n"."Grand Total"."\t".$showTotal['tView']."\t".$showTotal['tClick']."\t".$total_ctr."\t";
  exit;





?>