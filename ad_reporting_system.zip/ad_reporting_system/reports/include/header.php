<?php
$_SESSION['start'] = time(); // taking now logged in time
    if(!isset($_SESSION['expire'])){
        $_SESSION['expire'] = $_SESSION['start'] + (1* 36 * 30) ; // ending a session in 30 seconds
    }
    $now = time(); // checking the time now when home page starts
    if($now > $_SESSION['expire'])
    {        session_destroy();
        header('location:index.php');
    }
	
	if($_SESSION['user_level'] != '0' && $_SESSION['user_level'] != '1'){
	echo "This page not available!";
	header('location:index.php');}
	
	 

//echo "select * from trivago"; exit;
 $query=mysql_query("select * from trivago");
	   while($rs=mysql_fetch_assoc($query))
	   {
		   $rs1[]=$rs['imp'];
		   $click[]=$rs['click'];
		   $complete[]=$rs['complete'];
		   
	   }
$result=implode(',',$rs1); 	 
$clk=implode(',',$click); 
$com=implode(',',$complete);   
	  
    ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Airport Reporting System</title>

<!--                       CSS                       -->

<!-- Reset Stylesheet -->

<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />

<!-- Main Stylesheet -->

<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />

<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->

<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />

<!--line graph start-->
<link rel="stylesheet" href="csslinegraph/csslinegraph.css" type="text/css" media="screen" />

<!--line graph end-->
<!--                       Javascripts                       -->
<!-- date picker strat-->
<link href="date_picker/jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="date_picker/jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="date_picker/jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://www.amcharts.com/lib/3/amcharts.js"></script>
<script type="text/javascript" src="http://www.amcharts.com/lib/3/serial.js"></script>
<script type="text/javascript" src="http://www.amcharts.com/lib/3/themes/none.js"></script>

<!-- date picker end-->

<!--line graph  start-->
<style>
#chartdiv {
	width	: 100%;
	height	: 500px;
}
</style>



    <!--line graph js start-->
<script>
var chartData = generateChartData();

var chart = AmCharts.makeChart("chartdiv", {
    "type": "serial",
    "theme": "none",
    "pathToImages": "http://www.amcharts.com/lib/3/images/",
    "legend": {
        "useGraphSettings": true
    },
    "dataProvider": chartData,
    "valueAxes": [{
        "id":"v1",
        "axisColor": "#FF6600",
        "axisThickness": 2,
        "gridAlpha": 0,
        "axisAlpha": 1,
        "position": "left"
    }, {
        "id":"v2",
        "axisColor": "#FCD202",
        "axisThickness": 2,
        "gridAlpha": 0,
        "axisAlpha": 1,
        "position": "right"
    }, {
        "id":"v3",
        "axisColor": "#B0DE09",
        "axisThickness": 2,
        "gridAlpha": 0,
        "offset": 50,
        "axisAlpha": 1,
        "position": "left"
    }],
    "graphs": [{
        "valueAxis": "v1",
        "lineColor": "#FF6600",
        "bullet": "round",
        "bulletBorderThickness": 1,
        "hideBulletsCount": 30,
        "title": "Impression",
        "valueField": "visits",
		"fillAlphas": 0
    }, {
        "valueAxis": "v2",
        "lineColor": "#FCD202",
        "bullet": "square",
        "bulletBorderThickness": 1,
        "hideBulletsCount": 30,
        "title": "Clicks",
        "valueField": "hits",
		"fillAlphas": 0
    }, {
        "valueAxis": "v3",
        "lineColor": "#B0DE09",
        "bullet": "triangleUp",
        "bulletBorderThickness": 1,
        "hideBulletsCount": 30,
        "title": "Completion",
        "valueField": "views",
		"fillAlphas": 0
    }],
    "chartScrollbar": {},
    "chartCursor": {
        "cursorPosition": "mouse"
    },
    "categoryField": "date",
    "categoryAxis": {
        "parseDates": true,
        "axisColor": "#DADADA",
        "minorGridEnabled": true
    }
});

chart.addListener("dataUpdated", zoomChart);
zoomChart();
 

// generate some random data, quite different range
function generateChartData() {
    var chartData = [];
	//var imp=[3968,5892,7145,5942,6584,6987,6598,5689,7463,6565,6437,5663,5663,6498,7196,5855,7902,6052,5883,6937,8964,6484];
	var imp=[<?php print_r($result);?>];
	var cli=[<?php print_r($clk);?>];
	var com=[<?php print_r($com);?>];
    var firstDate = new Date();
    firstDate.setDate(firstDate.getDate() - 23);

    for (var i = 0; i < 100; i++) {
       
        var newDate = new Date(firstDate);
        newDate.setDate(newDate.getDate() + i);
        var visits = imp[i];
       var hits =cli[i];
      var views = com[i];

        chartData.push({
            date: newDate,
            visits: visits,
            hits: hits,
            views: views
        });
    }
    return chartData;
}

function zoomChart(){
    chart.zoomToIndexes(chart.dataProvider.length - 20, chart.dataProvider.length - 1);
}
</script>
<!--line graph js end-->
<!--line graph -->




<!-- jQuery -->

<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>

<!-- jQuery Configuration -->

<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>

<!-- Facebox jQuery Plugin -->

<script type="text/javascript" src="resources/scripts/facebox.js"></script>

<!-- jQuery WYSIWYG Plugin -->

<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>

<!-- jQuery DateTime Picker -->

<script type="text/javascript" src="js/jquery/jquery.datePicker.js"></script>



<!-- Internet Explorer .png-fix -->

</head>

<body>
<div id="body-wrapper">
<!-- Wrapper for the radial gradient background -->

<div id="sidebar">
  <div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
    
    <h1 id="sidebar-title"><a href="#"></a></h1>
    
    <!-- Logo (221px wide) --> 
    
    <a href="#"><img id="logo" src="resources/images/logo.png" alt="Admin logo" width="208px" height="60px" style="padding-left:7px;"/></a> 
    
    <!-- Sidebar Profile links -->
    
    <div id="profile-links"> 
      
      <!--	Hello, <a href="#" title="Edit your profile">John Doe</a>, you have <a href="#messages" rel="modal" title="3 Messages">3 Messages</a><br />

				<br />

				<a href="#" title="View the Site">View the Site</a> | -->
      <h3><a href="logout.php" title="Sign Out">Log Out</a></h3>
    </div>
    <?php  include("menu.php");?>
    <!-- End #main-nav --> 
    
  </div>
</div>
<!-- End #sidebar -->
