<?php
date_default_timezone_set("Asia/Kolkata");
error_reporting(0);
session_start();
ob_start();
$server_url = $_SERVER['HTTP_HOST'];
 if($server_url=='localhost'){
		$host = "localhost";
		$con_user = "root";
		$con_pwd = "";
		$con_db = "panel";
 }else{
 			$host = "localhost";

		$con_user = "root";

		$con_pwd = "K4hvdQ9tj9";

		$con_db = "delhi_airport";

 }

/*------connection 1------*/

$con1 = mysql_connect($host,$con_user,$con_pwd) or die("<span style='FONT-SIZE:11px; FONT-COLOR: #000000; font-family=tahoma;'><center>Can't establish database connection. Please report following error to the webmaster.<br><br>".mysql_error()."'</center>");
mysql_select_db($con_db,$con1) or die("<span style='FONT-SIZE:11px; FONT-COLOR: #000000; font-family=tahoma;'><center>database could not be connect. Please report following error to the webmaster.<br><br>".mysql_error()."'</center>");



/*------connection 2--------*/

//$con2 = mysql_connect("lyxel.net","lyxel_admin","Manish1@#",true) or die("<span style='FONT-SIZE:11px; FONT-COLOR: #000000; font-family=tahoma;'><center>Can't establish database connection. Please report following error to the webmaster.<br><br>".mysql_error()."'</center>");
//mysql_select_db('lyxel_dmp',$con2) or die("<span style='FONT-SIZE:11px; FONT-COLOR: #000000; font-family=tahoma;'><center>database could not be connect. Please report following error to the webmaster.<br><br>".mysql_error()."'</center>");


$site_name = "Delhi Airport Panel";
$sql_date_format = date('d-m-Y H:i:s');
$log_date = date('Y-m-d');
$log_time = date('H:i:s');
$date_time = date('h i | d M Y');
?>