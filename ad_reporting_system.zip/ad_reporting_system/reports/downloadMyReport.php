<?php

include("include/config.php");
/*------------------------*/
function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
  }

  // filename for download
  $filename =  "Download".date('Ymd').".xls";
  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel; charset=utf-8");

  $flag = false;
  //echo "select * from da_airport_report where campaign_name = '".$_POST['selectCampaign']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."'";exit;
  $SNo=1;
  $result = mysql_query("select * from airport_banner where campaign_name = '".$_GET['campName']."' AND publisher_name = '".$_SESSION['Airport_Name']."' AND date_time BETWEEN '".$_GET['sDate']."' AND '".$_GET['eDate']."'") or die('Query failed!');
  while(false !== ($row = mysql_fetch_assoc($result))) {
	  
    if(!$flag) {
      // display field/column names as first row
	  //echo ucwords(implode("\t", array_keys($row))) . "\r\n";
	  echo "Date"."\t"."AD Views"."\t"."Clicks"."\t"."CTR%"."\t"."No.of Unique AD Server Request"."\t"."No.of AD Server Request"."\t";
	  
	  $flag = true;
    }
	 		
			
/*----------calculation ctr---------*/
			$var_click = $row['click'];
			$var_imp = $row['ad_view'];
			$dateCTR = ($var_click/$var_imp)*100;
			$ctrDate = number_format($dateCTR, 2, '.', '');
			$spend = $row['click']*$row['cpc'];
	 //array_walk($row, 'cleanData');
    echo "\r\n".$row['date_time']."\t".$row['ad_view']."\t".$row['click']."\t".$ctrDate."\t".$row['no_uniq_ad']."\t".$row['no_ad_serve']."\r\n";
  }
  
  					
					$reportQuery = mysql_query("select sum(ad_view) as tView,sum(click) as tClick, sum(no_uniq_ad) as totalUniqAd, sum(no_ad_serve) as totalAdServed from airport_banner where campaign_name = '".$_GET['campName']."' AND publisher_name = '".$_SESSION['Airport_Name']."' AND date_time BETWEEN '".$_GET['sDate']."' AND '".$_GET['eDate']."' ") or die(mysql_error());
			$showTotal = mysql_fetch_array($reportQuery);
			$tx = $showTotal['tView'];
			$ty = $showTotal['tClick'];
			
			  
			   //$tCpc = mysql_fetch_array(mysql_query('SELECT SUM(`cpc`) as dCpc FROM `easypolicy` '));
			  $t_ctr = ($ty/$tx)*100;
			  $total_ctr = number_format($t_ctr, 2, '.', '');
					
					
  echo "Grand Total"."\t".$showTotal['tView']."\t".$showTotal['tClick']."\t".$total_ctr."\t".$showTotal['totalUniqAd']."\t".$showTotal['totalAdServed']."\t";
  exit;





?>