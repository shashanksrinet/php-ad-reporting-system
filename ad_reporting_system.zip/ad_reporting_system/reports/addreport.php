<?php 
include("include/config.php");
include("include/validation.php");
include("include/header.php");
if(isset($_POST['submit'])){
if(!$_GET['id']){
$insertQuery = "insert into trivago(date_time,imp,click,complete) values('".$_POST['date_time']."','".$_POST['imp']."','".$_POST['click']."','".$_POST['complete']."')";
mysql_query($insertQuery) or die(mysql_error());
		header('location:manage.php');
	}else{ 
		mysql_query("update trivago set date_time = '".$_POST['date_time']."', imp = '".$_POST['imp']."', click = '".$_POST['click']."', complete = '".$_POST['complete']."' where id = '".$_GET['id']."'") or die(mysql_error());
		header('location:manage.php');
		}
}
$rs = mysql_fetch_array(mysql_query("select * from trivago where id = '".$_GET['id']."'"));
?>

<div id="main-content"> <!-- Main Content Section with everything --> 
  <!---------- standard script---------------------> 
  
  <!---------- standard script--------------------->
  <div class="content-box">
    <div class="content-box-header">
      <h3> </h3>
      <ul class="content-box-tabs">
        <li><a href="#tab1" class="default-tab"></a></li>
      </ul>
      <div class="clear"></div>
    </div>
    <div class="content-box"><!-- Start Content Box -->
      
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
          
          <form action="" method="post" name="form1">
            <fieldset>
              <p>
                <label>Date</label>
                <input type="text" id="Datepicker1" value="<?php echo $rs['date_time'];?>" name="date_time" />
                <br />
              </p>
              <p>
                <label>Impression</label>
                <input type="text" id="medium-input" value="<?php echo $rs['imp'];?>" name="imp"  />
                <br />
              </p>
              <p>
                <label>Click</label>
                <input type="text" id="medium-input" value="<?php echo $rs['click'];?>" name="click" />
                <br />
              </p>
              <p>
                <label>Complete</label>
                <input type="text" id="medium-input" value="<?php echo $rs['complete'];?>" name="complete" />
                <br />
              </p>
              <p>
                <input class="button" type="submit" name="submit" value="Submit" />
              </p>
            </fieldset>
            <div class="clear"></div>
            <!-- End .clear -->
            
          </form>
        </div>
        <!-- End #tab1 --> 
      </div>
      <!-- End .content-box-content --> 
      
    </div>
    <!-- End .content-box-content --> 
    
  </div>
  <script language="javascript">

function calRevanue() {
       var txtFirstNumberValue = document.getElementsByName("ad_view");
       var txtSecondNumberValue = document.getElementsByName("rate");
       if (txtFirstNumberValue[0].value == "")
           txtFirstNumberValue[0].value = 0;
       if (txtSecondNumberValue[0].value == "")
           txtSecondNumberValue[0].value = 0;

       var result = parseFloat(txtFirstNumberValue[0].value) * parseFloat(txtSecondNumberValue[0].value);

       result = parseFloat(result).toFixed(2);

       if (!isNaN(result)) {
           document.getElementsByName("revenue")[0].value = result;
       }
   }
   
   
   
</script> 
  <!-- End .content-box -->
  <?php include("include/footer.php"); ?>
