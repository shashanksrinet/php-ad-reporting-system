<?PHP
include("include/config.php");


    function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
  }

  // filename for download
  $filename =  "Download".date('Ymd').".xls";
  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel; charset=utf-8");

  $flag = false;
  $SNo=1;
  $result = mysql_query("SELECT * FROM `trivago` ORDER BY `date_time` DESC") or die('Query failed!');
  while(false !== ($row = mysql_fetch_assoc($result))) {
	  
    if(!$flag) {
      // display field/column names as first row
	  //echo ucwords(implode("\t", array_keys($row))) . "\r\n";
	  echo "Date"."\t"."Impression"."\t"."Click"."\t"."CTR%"."\t"."Complete";
	  
	  $flag = true;
    }
	 		$date = explode(" ",$row['date_time']);
			
			
/*----------calculation ctr---------*/
			$var_click = $row['click'];
			$var_imp = $row['imp'];
			$dateCTR = ($var_click/$var_imp)*100;
			$ctrDate = number_format($dateCTR, 2, '.', '');
	 //array_walk($row, 'cleanData');
    echo "\r\n".$row['date_time']."\t".$row['imp']."\t".$row['click']."\t".$ctrDate."\t".$row['complete']."\t"."\r\n";
  }
  $rs2 = mysql_fetch_array(mysql_query("SELECT SUM(`imp`) AS totalImp, SUM(`click`) AS totalClick, SUM(`complete`) AS totalComplete FROM `trivago` "));
			    $a = $rs2['totalImp'];
				$b = $rs2['totalClick'];
				$c = ($b/$a)*100;
				$TotalCtr = number_format($c, 2, '.', '');
  					
				
			
  echo "Total"."\t".$rs2['totalImp']."\t".$rs2['totalClick']."\t".$TotalCtr."\t".$rs2['totalComplete']."\t";
  exit;
?>