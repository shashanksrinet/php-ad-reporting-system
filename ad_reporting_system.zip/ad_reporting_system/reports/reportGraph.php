<?php 
include("include/config.php");
include("include/header.php");
?>

<div id="main-content"> <!-- Main Content Section with everything -->
  
  <div class="content-box">
    <div class="content-box-header">
      <h3>Trivago Campaign's &nbsp;&nbsp;</h3>
      <div class="clear"></div>
    </div>
    <div class="content-box-content">
      <div class="tab-content default-tab" id="tab1">
        
        
        <div id="chartdiv">
        
        </div>
        
      </div>
      
      <!-- End #tab1 --> 
      
    </div>
    
    <!-- End .content-box-content --> 
    
  </div>
  
  <!-- End .content-box -->
  
  <?php include("include/footer.php"); ?>
