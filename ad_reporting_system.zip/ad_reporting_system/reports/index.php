<?php
require("include/config.php");
if(isset($_POST['submit'])){
	$login_validation_query = mysql_query("select * from login where BINARY username = '".$_POST['username']."' and BINARY password = '".$_POST['password']."'",$con1);
	$login_validation_num_rows = mysql_num_rows($login_validation_query);
	if($login_validation_num_rows == '0'){
	       $msg = "Wrong Username and Password.";
	}else{
		$login_validation = mysql_fetch_array($login_validation_query);
		$_SESSION['username'] = $login_validation['username'];
		$_SESSION['user_level'] = $login_validation['user_level'];
		$_SESSION['airportName'] = $login_validation['airportName'];
		if($_SESSION['user_level'] == 0){
			header("location:manage.php");
			}
            else if( $_SESSION['user_level'] == '1' && $_SESSION['username'] == 'tivago'){
            header("location:reports.php");
			}
	}}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
		<title>Airport Reporting System</title>
		
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
	
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
<script>
function validate()
{
	if(document.form1.username.value=="")
	{
		alert('Please Enter Username');
		document.form1.username.focus();
		return false;
	}
	if(document.form1.password.value=="")
	{
		alert('Please Enter Password');
		document.form1.password.focus();
		return false;
	}
return true;
}
</script>			
		
		
	</head>
  
	<body id="login">
		
		<div id="login-wrapper" class="png_bg">
			<div id="login-top">
			
				<h1>Simpla Admin</h1>
				<!-- Logo (221px width) -->
				<img id="logo" src="resources/images/logo.png" alt="Spidio" height="80px" width="255px" />
			</div> <!-- End #logn-top -->
			
			<div id="login-content">
				
			<form action="" method="POST" name="form1" onSubmit="return validate(this.form);">
				<?php if($msg){?>
					<div class="notification information png_bg">
						<div>
							<?php if($msg){echo $msg;}else{echo "Please fill username and password for login.";} ?>
						</div>
					</div>
					<?php }?>
					<p><label>Username</label>
						<input name="username" class="text-input" type="text" value="" />
					</p>
					<div class="clear"></div>
					<p><label>Password</label>
						<input name="password" class="text-input" type="password" value="" />
					</p>
					<div class="clear"></div>
					<p id="remember-password"><a href="" class="forgot-pwd">Forgot Password</a></p>
					<div class="clear"></div>
					<p><input class="button" name="submit" type="submit" value="Sign In" /></p>
				</form>
			</div> <!-- End #login-content -->
			
		</div> <!-- End #login-wrapper -->
		
  </body>
  
</html>
