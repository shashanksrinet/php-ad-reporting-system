<?php 
include("include/config.php");
include("include/header.php");
/*------------------------*/

?>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});


</script>
  <div id="main-content">  
    
    <!---------- standard script---------------------> 
    
    <!---------- standard script--------------------->
    
    <div class="content-box">
      <div class="content-box-header">
        <h3> Airport Reporting System  &nbsp;|&nbsp;&nbsp;<?php echo $_SESSION['aName'];?></h3>
        
        <div class="clear"></div>
       
      </div>
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1">
        <center><h4>Download Report</h4></center>
        <br><br>
        <hr><br><br>
          <table>
            <tbody>
            <form name="myreport" method="post" action="downloadMyReport.php">
              <label>Select Campaign</label>
              &nbsp;:
              <select name="selectCampaign">
              <option>-select-</option>
              <?php
			  
			  
			  
			  
			  $selectCamp = mysql_query("select campaign_name from da_airport_report where publisher_name = '".$_SESSION['airportName']."' group by campaign_name") or die(mysql_error());
			  while($campName = mysql_fetch_array($selectCamp))
			  {
			   ?>
              <option value="<?php echo $campName['campaign_name']; ?>"><?php echo $campName['campaign_name']; ?></option>
             <?php }?>
              </select>
              &nbsp;&nbsp;&nbsp;
              
              <label>Start Date</label>
              &nbsp;:
              <input type="text" id="Datepicker1" value="" name="start_date">
              &nbsp;&nbsp;&nbsp;
              <label>End Date</label>
              
              &nbsp;:
              <input type="text" id="Datepicker2" value="" name="end_date">
              
              
              &nbsp;&nbsp;
              <input type="submit" name="submit" value="Submit" >
              </form>
            </tbody>
             </table>
             <br><br>
               <br><br>
        <div class="tab-content default-tab" id="tab1">
        
       
            
            </div></div>
            
            
            
         
        
        <!-- End #tab1 --> 
        
      </div>
      
      <!-- End .content-box-content --> 
      
    </div>
    
    <!-- End .content-box -->
    
    <?php include("include/footer.php"); ?>
