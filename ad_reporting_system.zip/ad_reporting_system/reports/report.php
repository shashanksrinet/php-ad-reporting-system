<?php 
//echo "testing"; exit;
include("include/config.php");

include("include/function.php");

include("include/validation.php");

?>
<?php include("include/header.php");

?>
  <div id="main-content"> <!-- Main Content Section with everything -->
    <div class="content-box-content">
      <table>
        <tbody>
          <?php if($_POST['selectCampaign']){?>
          <tr>
            <th><h4 style="color:#666">Campaign Name:&nbsp;&nbsp;<?php echo ucwords($_POST['selectCampaign']);?>&nbsp;&nbsp;&nbsp;From:&nbsp;&nbsp;<?php echo $_POST['start_date'];?> &nbsp;&nbsp;To:&nbsp;&nbsp; <?php echo $_POST['end_date'];?>&nbsp;&nbsp;&nbsp;<a href="downloadMyReport.php?campName=<?php echo $_POST['selectCampaign'];?>&sDate=<?php echo $_POST['start_date'];?>&eDate=<?php echo $_POST['end_date'];?>">Download</a></h4></th>
          </tr>
          <?php }?>
        <form name="myreport" method="post" action="">
         <label>Select Campaign</label>
         <select name="campaign_name">
         <option>-Select-</option>
         <option value="kellogs">Kellogs</option>
          <option value="SamsungNote-B">Samsung</option>
         <option>-Select-</option>
         </select>
         &nbsp;:
          <label>Start Date</label>
          &nbsp;:
          <input type="text" id="Datepicker1" value="" name="start_date">
          &nbsp;&nbsp;&nbsp;
          <label>End Date</label>
          &nbsp;:
          <input type="text" id="Datepicker2" value="" name="end_date">
          &nbsp;&nbsp;
          <input type="submit" name="submit" value="Submit" >
        </form>
          </tbody>
        
      </table>
    </div>
    <div class="content-box">
      <div class="content-box-header">
        <h3><?php
		$c_name="";
		 if($_POST['campaign_name']=="kellogs"){
		$c_name="Kellogs";
			}
			else if($_POST['campaign_name']=="SamsungNote-B"){
				$c_name="Samsung";
				}
				else{
					$c_name="";
					}
				echo $c_name;?> Campaign's</h3>
        <div class="clear"></div>
      </div>
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>AD Views</th>
                <th>Clicks</th>
                <th>CTR%</th>
                <th>No.of unique Address Request</th>
                <th>No.of AD Server Request</th>
                <th>Revenue</th>
              </tr>
            </thead>
            <tbody>
              <?php
			  //echo "select * from airport_banner where campaign_name = '".$_POST['selectCampaign']."' AND publisher_name = '".$_SESSION['airportName']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."' ORDER BY date_time DESC ";
			$query= mysql_query("select * from airport_banner where campaign_name ='".$_POST['campaign_name']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."' ORDER BY date_time DESC ");
			while($rs = mysql_fetch_array($query)){
				$x = $rs['ad_view'];
				$y = $rs['click'];
				$z = ($y/$x)*100;
				$ctr = number_format($z, 2, '.', '');
			 ?>
              <tr align="center">
                <td><?php echo $rs['date_time'];?></td>
                <td><?php echo $rs['ad_view'];?></td>
                <td><?php echo $rs['click'];?></td>
                <th><?php echo $ctr;?></th>
                <td><?php echo $rs['no_uniq_ad'];?></td>
                <td><?php echo $rs['no_ad_serve'];?></td>
                <td><?php echo $rs['revenue'];?></td>
              </tr>
              <?php $no++;
			}
			 ?>
              <tr>
              <?php
              $rs2 = mysql_fetch_array(mysql_query("SELECT SUM(`ad_view`) AS totalView, SUM(`click`) AS totalClick, SUM(`no_uniq_ad`) AS uniqAd, SUM(`no_ad_serve`) AS adServe FROM airport_banner where campaign_name ='".$_POST['campaign_name']."'  AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."' ORDER BY date_time DESC "));
			    $a = $rs2['totalView'];
				$b = $rs2['totalClick'];
				$c = ($b/$a)*100;
				$TotalCtr = number_format($z, 2, '.', '');
			  ?>
              <th><strong>Grand Total</strong></th>
              <th><strong><?php echo $rs2['totalView'];?></strong></th>
              <th><strong><?php echo $rs2['totalClick'];?></strong></th>
              <th><strong><?php echo $TotalCtr;?></strong></th>
              <th><strong><?php echo $rs2['uniqAd'];?></strong></th>
              <th><strong><?php echo $rs2['adServe'];?></strong></th>
              <th><strong>0.00</strong></th>
              </tr>
            </tbody>
          </table>
        </div>
        
        <!-- End #tab1 --> 
        
      </div>
      
      <!-- End .content-box-content --> 
      
    </div>
    
    <!-- End .content-box -->
    
    <?php include("include/footer.php"); ?>
