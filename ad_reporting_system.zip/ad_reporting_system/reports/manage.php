<?php 
include("include/config.php");
include("include/header.php");
?>
  <div id="main-content"> <!-- Main Content Section with everything -->
    <div class="content-box-content">
      
    </div>
    <div class="content-box">
      <div class="content-box-header">
        <h3>Panel</h3>
        <div class="clear"></div>
      </div>
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Impression's</th>
                <th>Click's</th>
                <th>CTR%</th>
                <th>Complete</th>
                <th>Manage</th>
              </tr>
            </thead>
            <tbody>
              <?php
			$query= mysql_query("SELECT * FROM `trivago` ORDER BY `date_time` DESC");
			while($rs = mysql_fetch_array($query)){
				$x = $rs['imp'];
				$y = $rs['click'];
				$z = ($y/$x)*100;
				$ctr = number_format($z, 2, '.', '');
			 ?>
              <tr align="center">
                <td><?php echo $rs['date_time'];?></td>
                <td><?php echo $rs['imp'];?></td>
                <td><?php echo $rs['click'];?></td>
                <th><?php echo $ctr;?></th>
                <td><?php echo $rs['complete'];?></td>
                <td><a href="addreport.php?id=<?php echo $rs['id'];?>">Edit</a>&nabla;&nabla;<a href="delete.php?id=<?php echo $rs['id'];?>&camp=tri" onclick="return confirm('Are you sure!');">Delete</a></td>
              </tr>
              <?php $no++;} ?>
              <tr>
              <?php
              $rs2 = mysql_fetch_array(mysql_query("SELECT SUM(`imp`) AS totalImp, SUM(`click`) AS totalClick, SUM(`complete`) AS totalComplete FROM `trivago` "));
			    $a = $rs2['totalImp'];
				$b = $rs2['totalClick'];
				$c = ($b/$a)*100;
				$TotalCtr = number_format($c, 2, '.', '');
			  ?>
              <th>Total</th>
              <th><?php echo $rs2['totalImp'];?></th>
              <th><?php echo $rs2['totalClick'];?></th>
              <th><?php echo $TotalCtr;?></th>
              <th><?php echo $rs2['totalComplete'];?></th>
              <td></td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <!-- End #tab1 --> 
        
      </div>
      
      <!-- End .content-box-content --> 
      
    </div>
    
    <!-- End .content-box -->
    
    <?php include("include/footer.php"); ?>
