<?php
include("include/config.php");

if($_GET['camp'] == 'tri')  {     
	mysql_query("delete from trivago where id = '".$_GET['id']."'") or die(mysql_error());
	header("location:manage.php");
}


 ?>
