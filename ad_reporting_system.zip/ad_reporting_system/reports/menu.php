<?php 

include("config.php");



ob_start();

?>

 
  <ul id="main-nav">
  <li><a href="#" class="nav-top-item" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Reports</font></a></li>
               <ul>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="reportGraph.php">Report Graph</a></li>
                <li><a href="download.php">Download</a></li>
                </ul>
				<?php 
				if($_SESSION['user_level'] == '0'){
				?>
                <ul>
       <li><a href="#" class="nav-top-item" style="  background: transparent url('resources/images/bg-menu-item-green.gif') right center no-repeat; /* Background image for default color scheme - green */
                padding: 10px 15px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                display: block;
                text-decoration: none;"><font size="+4">Manage Reports</font></a></li>
                <ul>
                <li><a href="manage.php">Manage Report</a></li>
                <li><a href="addreport.php">Add Report</a></li>
                
                </ul>          
                <?php };?>
  <ul>

</ul>
