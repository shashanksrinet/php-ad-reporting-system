<?php 
include("include/config.php");
include("include/header.php");
?>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});


</script>
  <div id="main-content">  
    
    <!---------- standard script---------------------> 
    
    <!---------- standard script--------------------->
    
    <div class="content-box">
      <div class="content-box-header">
      
      
      
        <h3> Reporting System  &nbsp;|&nbsp;&nbsp;<?php echo $_SESSION['aName'];?></h3>
        
        <div class="clear"></div>
       
      </div>
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1">
        
          <table>
            <tbody>
            <?php if($_POST['selectCampaign']){?>
            <tr>
            <th><h4 style="color:#666">Campaign Name:&nbsp;&nbsp;<?php echo ucwords($_POST['selectCampaign']);?>&nbsp;&nbsp;&nbsp;From:&nbsp;&nbsp;<?php echo $_POST['start_date'];?> &nbsp;&nbsp;To:&nbsp;&nbsp; <?php echo $_POST['end_date'];?>&nbsp;&nbsp;&nbsp;<a href="downl.php?campName=<?php echo $_POST['selectCampaign'];?>&sDate=<?php echo $_POST['start_date'];?>&eDate=<?php echo $_POST['end_date'];?>">Download</a></h4></th>
            </tr>
            <?php }?>
            <form name="myreport" method="post" action="">
              <label>Select Campaign</label>
              &nbsp;:
              <select name="selectCampaign">
              <option>-select-</option>
              <?php
			  $selectCamp = mysql_query("select campaign_name from report_backup group by campaign_name",$con1) or die(mysql_error());
			  while($campName = mysql_fetch_array($selectCamp))
			  {
			   ?>
              <option value="<?php echo $campName['campaign_name']; ?>"><?php echo $campName['campaign_name']; ?></option>
             <?php }?>
              </select>
              &nbsp;&nbsp;&nbsp;
              
              <label>Start Date</label>
              &nbsp;:
              <input type="text" id="Datepicker1" value="" name="start_date">
              &nbsp;&nbsp;&nbsp;
              <label>End Date</label>
              
              &nbsp;:
              <input type="text" id="Datepicker2" value="" name="end_date">
              
              
              &nbsp;&nbsp;
              <input type="submit" name="submit" value="Submit" >
              </form>
            </tbody>
             </table>
             <br><br>
             <hr>
               <br><br>
        <div class="tab-content default-tab" id="tab1">
        <table>
            <tbody>
            <tr>
            <th><strong>Date</strong></th>
            <th><strong>Impression</strong></th>
            <th><strong>Clicks</strong></th>
            <th><strong>CTR%</strong></th>
            </tr>
            </tbody>
            <?php 
			if(isset($_POST['submit'])){
			//echo 	"select * from da_airport_reportBackup where campaign_name = '".$_POST['selectCampaign']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."' ORDER BY date_time DESC ";
				$reportQuery = mysql_query("select * from report_backup where campaign_name = '".$_POST['selectCampaign']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."' ORDER BY date_time ASC ",$con1) or die(mysql_error());
				while($showReport = mysql_fetch_array($reportQuery)){
					$x = $showReport['impration'] ;
					$y = $showReport['click'] ;
					$tctr = ($y/$x)*100;
					$ctr = number_format($tctr, 2, '.', '');
			
			
			?>
            <tr>
            <td><?php echo $showReport['date_time'] ;?></td>
            <td><?php echo $showReport['impration'] ;?></td>
            <td><?php echo $showReport['click'] ;?></td>
            <td><?php echo $ctr ;?></td>
            <td><a href='edit_test.php?id=<?php echo $showReport['id']?>'>Edit</a></td>
            <td><a href='delete.php?id=<?php echo $showReport['id']?>'>Delete</a></td><tr>
            </tr>
            
            <?php }} 
			$reportQuery = mysql_query("select sum(impration) as tView,sum(click) as tClick   from report_backup where campaign_name = '".$_POST['selectCampaign']."' AND date_time BETWEEN '".$_POST['start_date']."' AND '".$_POST['end_date']."'",$con1) or die(mysql_error());
			$showTotal = mysql_fetch_array($reportQuery);
			$tx = $showTotal['tView'];
			$ty = $showTotal['tClick'];
			$ttctr = ($ty/$tx)*100;
			$totalctr = number_format($ttctr, 2, '.', '');
			?>
            <tr>
            <th><strong>Grand Total</strong></th>
            <th><strong><?php echo $showTotal['tView'];?></strong></th>
            <th><strong><?php echo $showTotal['tClick'];?></strong></th>
            <th><strong><?php echo $totalctr;?></strong></th>
            </tr>
            </table>
            </div></div>
            
        
        <!-- End #tab1 --> 
        
      </div>
      
      <!-- End .content-box-content --> 
      
    </div>
    
    <!-- End .content-box -->
    
    <?php include("include/footer.php"); ?>
