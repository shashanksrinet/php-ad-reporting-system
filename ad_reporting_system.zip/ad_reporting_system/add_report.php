<?php 
include("include/config.php");
include("include/header.php");
if(isset($_POST['submit'])){
	if(!$_GET['id']){
    $insertQuery = "insert into report_backup(impration,click,campaign_name,date_time) values('".$_POST['impration']."','".$_POST['click']."','".$_POST['campaign_name']."','".$_POST['date_time']."')";
    mysql_query($insertQuery,$con1) or die(mysql_error());
      echo '<script language="javascript">';
      echo 'alert("Data successfully added!")';
      echo '</script>';
    		//header('location:manage.php');
    	}
}
$rs = mysql_fetch_array(mysql_query("select * from report_backup where id = '".$_GET['id']."'",$con1));
?>

<div id="main-content"> <!-- Main Content Section with everything --> 
  <!---------- standard script---------------------> 
  
  <!---------- standard script--------------------->
  <div class="content-box">
    <div class="content-box-header">
      <h3>Add Report</h3>
      <ul class="content-box-tabs">
        <li><a href="#tab1" class="default-tab"></a></li>
      </ul>
      <div class="clear"></div>
    </div>
    <div class="content-box"><!-- Start Content Box -->
      
      <div class="content-box-content">
        <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
          
          <form action="" method="post" name="myForm" onsubmit = "return(validate());">
            <fieldset>
              <p>
                <label>Date</label>
                <input type="text" value="<?php echo $rs['date_time'];?>" name="date_time" id="Datepicker1" />
                <br />
              </p>
              <p>
                <label>Impression</label>
                <input type="text" id="medium-input" value="<?php echo $rs['impration'];?>" name="impration" />
                <br />
              </p>
              <p>
                <label>Click</label>
                <input type="text" id="medium-input" value="<?php echo $rs['click'];?>" name="click"  />
                <br />
              </p>
              <p>
                <label>Campaign Name</label>
                <select name="campaign_name">
              <option value="-1">-select-</option>
              <?php
              $selectCamp = mysql_query("select campaign_name from report_backup group by campaign_name",$con1) or die(mysql_error());
              while($campName = mysql_fetch_array($selectCamp))
            {
              ?>
              <option value="<?php echo $campName['campaign_name']; ?>"><?php echo $campName['campaign_name']; ?></option>
            <?php }?>
              </select>
                <!-- <input type="text" id="medium-input" value="<?php echo $rs['campaign_name'];?>" name="campaign_name" /> -->
                <br />
              </p>
              
              <p>
                <input class="button" type="submit" name="submit" value="Submit" />
              </p>
            </fieldset>
            <div class="clear"></div>
            <!-- End .clear -->
            
          </form>
        </div>
        <!-- End #tab1 --> 
      </div>
      <!-- End .content-box-content --> 
      
    </div>
    <!-- End .content-box-content --> 
    
  </div>
  <script type = "text/javascript">
   <!--
      // Form validation code will come here.
      function validate() {
      
         if( document.myForm.date_time.value == "" ) {
            alert( "Please provide Date!" );
            document.myForm.date_time.focus() ;
            return false;
         }
         if( document.myForm.impration.value == "" ) {
            alert( "Please provide Impression!" );
            document.myForm.impration.focus() ;
            return false;
         }
         if( document.myForm.click.value == "" ) {
            alert( "Please provide Click!" );
            document.myForm.click.focus() ;
            return false;
         }
         
         if( document.myForm.campaign_name.value == "-1" ) {
            alert( "Please provide Campaign Name!" );
            return false;
         }
         return( true );
      }
   //-->
</script> 
  <!-- End .content-box -->
  <?php include("include/footer.php"); ?>
